package com.hanguktopik.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String PREFS = "hanguk_topik_prefs";
    private static final String KEY_URL = "server_url";
    private WebView webView;
    private LinearLayout connectPanel;
    private EditText urlInput;
    private TextView statusText;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        buildUi();
        configureWebView();
        openBundledApp();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(247, 247, 244));

        connectPanel = new LinearLayout(this);
        connectPanel.setOrientation(LinearLayout.VERTICAL);
        connectPanel.setPadding(dp(16), dp(14), dp(16), dp(12));
        connectPanel.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText("HANGUK TOPIK");
        title.setTextColor(Color.rgb(23, 35, 60));
        title.setTextSize(20);
        title.setGravity(Gravity.START);
        title.setTypeface(null, 1);
        connectPanel.addView(title);

        statusText = new TextView(this);
        statusText.setTextColor(Color.rgb(104, 112, 128));
        statusText.setTextSize(13);
        statusText.setPadding(0, dp(8), 0, dp(8));
        connectPanel.addView(statusText);

        urlInput = new EditText(this);
        urlInput.setSingleLine(true);
        urlInput.setHint("http://192.168.1.25:4173");
        urlInput.setText(prefs.getString(KEY_URL, ""));
        connectPanel.addView(urlInput, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.END);
        buttons.setPadding(0, dp(10), 0, 0);

        Button open = new Button(this);
        open.setText("OPEN APP");
        open.setOnClickListener(v -> openUrl(urlInput.getText().toString()));
        buttons.addView(open);

        Button clear = new Button(this);
        clear.setText("RESET");
        clear.setOnClickListener(v -> {
            prefs.edit().remove(KEY_URL).apply();
            CookieManager.getInstance().removeAllCookies(null);
            urlInput.setText("");
            showConnectPanel("Saved URL cleared.");
        });
        buttons.addView(clear);
        connectPanel.addView(buttons);

        webView = new WebView(this);
        root.addView(connectPanel);
        root.addView(webView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1
        ));
        setContentView(root);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                connectPanel.setVisibility(View.GONE);
                super.onPageFinished(view, url);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    showConnectPanel("Could not open the app. Check that your PC server is running and your phone is on the same Wi‑Fi.");
                }
                super.onReceivedError(view, request, error);
            }
        });

        webView.setOnLongClickListener(v -> {
            showConnectPanel("Advanced testing: enter a hosted URL only if you want to override the bundled app.");
            return true;
        });
    }

    private void openBundledApp() {
        connectPanel.setVisibility(View.GONE);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void openUrl(String raw) {
        String url = raw == null ? "" : raw.trim();
        if (url.isEmpty()) {
            showConnectPanel("Enter the server URL first.");
            return;
        }
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "http://" + url;
        }
        if (!isOnline()) {
            showConnectPanel("This device is offline. Connect to the same Wi‑Fi as your PC.");
            return;
        }
        prefs.edit().putString(KEY_URL, url).apply();
        urlInput.setText(url);
        statusText.setText("Opening " + url);
        webView.loadUrl(url);
    }

    private void showConnectPanel(String message) {
        statusText.setText(message);
        connectPanel.setVisibility(View.VISIBLE);
    }

    private boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return true;
        NetworkInfo info = cm.getActiveNetworkInfo();
        return info != null && info.isConnected();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
