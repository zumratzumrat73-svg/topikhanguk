(() => {
  const DB_KEY = 'hanguk-topik-android-db-v1';
  const SESSION_KEY = 'hanguk-topik-android-session';
  const ADMIN_KEY = 'hanguk-topik-android-admin-session';
  const now = () => new Date().toISOString();
  const id = () => (crypto.randomUUID ? crypto.randomUUID() : 'id-' + Date.now() + '-' + Math.random().toString(16).slice(2));
  const json = (data, status = 200) => new Response(JSON.stringify(data), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8' }
  });
  const clone = x => JSON.parse(JSON.stringify(x));
  const safeTest = t => clone(t, (k, v) => k === 'correct' ? undefined : v);

  function demo(type) {
    return {
      id: id(),
      type,
      title: type === 'I' ? 'TOPIK I Starter Test' : 'TOPIK II Starter Test',
      number: 1,
      description: 'Offline practice test bundled inside the Android app.',
      published: true,
      createdAt: now(),
      sections: {
        listening: [1, 2, 3].map(n => ({
          id: id(),
          number: n,
          text: ['What did the speaker buy?', 'Where will they meet?', 'What time does the class begin?'][n - 1],
          choices: ['A book', 'A ticket', 'A meal', 'A bag'],
          correct: n,
          explanation: 'Listen for the key noun or time expression.',
          points: 2
        })),
        reading: [1, 2, 3].map(n => ({
          id: id(),
          number: n,
          text: ['Choose the word that means school.', 'Choose the polite greeting.', 'Complete: 저는 한국어를 ___.'][n - 1],
          choices: n === 1
            ? ['학교', '사과', '바다', '우유']
            : n === 2
              ? ['안녕하세요', '잘 자', '몰라요', '아니']
              : ['공부해요', '먹어요', '자요', '닫아요'],
          correct: 1,
          explanation: 'The first choice is the best answer.',
          points: 2
        })),
        writing: type === 'II' ? [{
          id: id(),
          number: 1,
          prompt: 'Write 80–150 Korean characters introducing your daily routine.',
          maxPoints: 20,
          sample: '저는 아침 일곱 시에 일어납니다.',
          guide: 'Organization 5, vocabulary 5, grammar 5, task completion 5.',
          min: 80,
          max: 150
        }] : []
      }
    };
  }

  function loadDb() {
    const existing = localStorage.getItem(DB_KEY);
    if (existing) return JSON.parse(existing);
    const db = {
      users: [],
      tests: [demo('I'), demo('II')],
      attempts: [],
      writing: [],
      admin: { code: 'herculesAI', password: 'hercules@2026', failures: 0, lockedUntil: 0 }
    };
    saveDb(db);
    return db;
  }

  function saveDb(db) {
    localStorage.setItem(DB_KEY, JSON.stringify(db));
  }

  function currentUser(db) {
    const uid = localStorage.getItem(SESSION_KEY);
    return db.users.find(u => u.id === uid);
  }

  function isAdmin(db) {
    const exp = Number(localStorage.getItem(ADMIN_KEY) || 0);
    return exp > Date.now();
  }

  function scoreWriting(question, rawAnswer) {
    const answer = String(rawAnswer || '').trim();
    const max = Number(question.maxPoints || 20);
    const len = [...answer].length;
    const minLen = Number(question.min || 0);
    const maxLen = Number(question.max || 500);
    const koreanChars = (answer.match(/[가-힣]/g) || []).length;
    const sentences = (answer.match(/[.!?。！？]|다\.?|요\.?|니다\.?/g) || []).length;
    const polite = /(습니다|ㅂ니다|어요|아요|예요|이에요|합니다|됩니다|있습니다)/.test(answer);
    const connectors = /(그리고|그래서|하지만|또한|때문에|먼저|다음|마지막|그러나|예를 들어)/.test(answer);
    let task = 0;
    if (len > 0) task += .35;
    if (!minLen || len >= minLen) task += .35;
    if (!maxLen || len <= maxLen) task += .15;
    if (question.prompt && answer.length) task += .15;
    let grammar = 0;
    if (koreanChars / Math.max(len, 1) > .45) grammar += .35;
    if (polite) grammar += .25;
    if (sentences >= 2) grammar += .25;
    if (!/[^\s가-힣ㄱ-ㅎㅏ-ㅣ0-9.,!?'"()\-~]/.test(answer)) grammar += .15;
    let vocab = 0;
    if (answer.split(/\s+/).filter(Boolean).length >= 8) vocab += .3;
    if (koreanChars >= Math.min(minLen || 30, 30)) vocab += .35;
    if (/[가-힣]{3,}/.test(answer)) vocab += .2;
    if (connectors) vocab += .15;
    let organization = 0;
    if (sentences >= 2) organization += .4;
    if (connectors) organization += .3;
    if (len >= Math.min(minLen || 50, 50)) organization += .2;
    if (/[.?!。！？]$/.test(answer)) organization += .1;
    const score = Math.max(0, Math.min(max, Math.round(((task + grammar + vocab + organization) / 4) * max)));
    const feedback = [
      `Task completion: ${Math.round(task * 100)}%.`,
      `Grammar/form: ${Math.round(grammar * 100)}%.`,
      `Vocabulary: ${Math.round(vocab * 100)}%.`,
      `Organization: ${Math.round(organization * 100)}%.`,
      len < minLen ? `Write more: this answer has ${len} characters, target minimum is ${minLen}.` : '',
      !polite ? 'Use more natural Korean sentence endings such as -습니다, -아요, or -어요.' : '',
      !connectors ? 'Add connectors such as 그리고, 그래서, 하지만 to make the answer flow better.' : '',
      score >= Math.ceil(max * .8) ? 'Strong answer. Keep polishing grammar and expression variety.' : ''
    ].filter(Boolean).join(' ');
    return { score, max, provider: 'offline-local', feedback };
  }

  async function readBody(init) {
    if (!init || !init.body) return {};
    if (typeof init.body === 'string') return JSON.parse(init.body || '{}');
    return {};
  }

  const realFetch = window.fetch.bind(window);
  window.fetch = async (input, init = {}) => {
    const url = typeof input === 'string' ? input : input.url;
    const u = new URL(url, location.href);
    if (!u.pathname.startsWith('/api/')) return realFetch(input, init);

    const db = loadDb();
    const b = await readBody(init);
    const method = (init.method || 'GET').toUpperCase();
    const user = currentUser(db);

    try {
      if (u.pathname === '/api/register' && method === 'POST') {
        if (!b.name || !/^\S+@\S+\.\S+$/.test(b.email) || String(b.password || '').length < 8) return json({ error: 'Enter a name, valid email, and password of at least 8 characters.' }, 400);
        if (db.users.some(x => x.email === String(b.email).toLowerCase())) return json({ error: 'Email already registered.' }, 409);
        db.users.push({ id: id(), name: b.name.trim(), email: String(b.email).toLowerCase(), password: b.password, language: b.language || 'en', createdAt: now() });
        saveDb(db);
        return json({ ok: true }, 201);
      }

      if (u.pathname === '/api/login' && method === 'POST') {
        const x = db.users.find(x => x.email === String(b.email).toLowerCase() && x.password === b.password);
        if (!x) return json({ error: 'Invalid email or password.' }, 401);
        localStorage.setItem(SESSION_KEY, x.id);
        return json({ user: { id: x.id, name: x.name, email: x.email, language: x.language } });
      }

      if (u.pathname === '/api/logout') {
        localStorage.removeItem(SESSION_KEY);
        return json({ ok: true });
      }

      if (u.pathname === '/api/me') {
        return user ? json({ id: user.id, name: user.name, email: user.email, language: user.language }) : json({ error: 'Unauthorized' }, 401);
      }

      if (u.pathname === '/api/admin/login' && method === 'POST') {
        if (db.admin.lockedUntil > Date.now()) return json({ error: 'Too many attempts. Try again later.' }, 429);
        if (b.code !== db.admin.code || b.password !== db.admin.password) {
          db.admin.failures++;
          if (db.admin.failures >= 5) {
            db.admin.lockedUntil = Date.now() + 300000;
            db.admin.failures = 0;
          }
          saveDb(db);
          return json({ error: 'Invalid admin code or password.' }, 401);
        }
        db.admin.failures = 0;
        localStorage.setItem(ADMIN_KEY, String(Date.now() + 3600000));
        saveDb(db);
        return json({ ok: true });
      }

      if (u.pathname.startsWith('/api/admin/')) {
        if (!isAdmin(db)) return json({ error: 'Admin session required' }, 403);
        if (u.pathname === '/api/admin/me') return json({ ok: true });
        if (u.pathname === '/api/admin/stats') return json({
          users: db.users.length,
          topik1: db.tests.filter(x => x.type === 'I').length,
          topik2: db.tests.filter(x => x.type === 'II').length,
          attempts: db.attempts.filter(x => x.status === 'SUBMITTED').length,
          writing: db.writing.length
        });
        if (u.pathname === '/api/admin/data') return json({
          tests: db.tests,
          attempts: db.attempts.map(a => ({ ...a, user: db.users.find(x => x.id === a.userId), test: db.tests.find(x => x.id === a.testId) })),
          writing: db.writing.map(w => ({ ...w, user: db.users.find(x => x.id === w.userId), test: db.tests.find(x => x.id === w.testId) }))
        });
        if (u.pathname === '/api/admin/test' && method === 'POST') {
          const t = { ...b, id: b.id || id(), createdAt: b.createdAt || now() };
          const n = db.tests.findIndex(x => x.id === t.id);
          n < 0 ? db.tests.push(t) : db.tests[n] = t;
          saveDb(db);
          return json(t);
        }
        if (u.pathname === '/api/admin/test' && method === 'DELETE') {
          db.tests = db.tests.filter(x => x.id !== b.id);
          saveDb(db);
          return json({ ok: true });
        }
        if (u.pathname === '/api/admin/ai-review' && method === 'POST') {
          const w = db.writing.find(x => x.id === b.id);
          if (!w) return json({ error: 'Missing submission' }, 404);
          const ai = scoreWriting(w.question, w.answer);
          Object.assign(w, { score: ai.score, feedback: ai.feedback, ai, status: 'AI SCORED' });
          updateAttempt(db, w.attemptId);
          saveDb(db);
          return json(w);
        }
        if (u.pathname === '/api/admin/review' && method === 'POST') {
          const w = db.writing.find(x => x.id === b.id);
          if (!w) return json({ error: 'Missing submission' }, 404);
          Object.assign(w, { score: +b.score, feedback: b.feedback, status: 'REVIEWED', reviewedAt: now() });
          updateAttempt(db, w.attemptId);
          saveDb(db);
          return json({ ok: true });
        }
        if (u.pathname === '/api/admin/security' && method === 'POST') {
          if (b.currentPassword !== db.admin.password) return json({ error: 'Current admin password is incorrect.' }, 400);
          if (b.code) db.admin.code = b.code;
          if (b.password) {
            db.admin.password = b.password;
            localStorage.removeItem(ADMIN_KEY);
          }
          saveDb(db);
          return json({ ok: true });
        }
        if (u.pathname === '/api/admin/logout') {
          localStorage.removeItem(ADMIN_KEY);
          return json({ ok: true });
        }
      }

      if (!user) return json({ error: 'Unauthorized' }, 401);

      if (u.pathname === '/api/profile' && method === 'PATCH') {
        if (b.language) user.language = b.language;
        if (b.name) user.name = b.name.trim();
        if (b.password) {
          if (b.currentPassword !== user.password) return json({ error: 'Current password is incorrect.' }, 400);
          user.password = b.password;
        }
        saveDb(db);
        return json({ ok: true });
      }

      if (u.pathname === '/api/tests' && method === 'GET') return json(db.tests.filter(t => t.published).map(t => JSON.parse(JSON.stringify(t, (k, v) => k === 'correct' ? undefined : v))));
      if (u.pathname.startsWith('/api/tests/') && method === 'GET') {
        const t = db.tests.find(x => x.id === u.pathname.split('/').pop() && x.published);
        return t ? json(JSON.parse(JSON.stringify(t, (k, v) => k === 'correct' ? undefined : v))) : json({ error: 'Test not found' }, 404);
      }
      if (u.pathname === '/api/attempts' && method === 'GET') return json(db.attempts.filter(x => x.userId === user.id));
      if (u.pathname === '/api/attempts/save' && method === 'POST') {
        let a = db.attempts.find(x => x.id === b.id && x.userId === user.id && x.status === 'IN_PROGRESS');
        if (!a) {
          a = { id: id(), userId: user.id, testId: b.testId, status: 'IN_PROGRESS', answers: {}, writing: {}, section: 'listening', question: 0, startedAt: now() };
          db.attempts.push(a);
        }
        Object.assign(a, { answers: b.answers || a.answers, writing: b.writing || a.writing, section: b.section || a.section, question: b.question ?? a.question, updatedAt: now() });
        saveDb(db);
        return json(a);
      }
      if (u.pathname === '/api/attempts/submit' && method === 'POST') {
        const a = db.attempts.find(x => x.id === b.id && x.userId === user.id);
        if (!a || a.status === 'SUBMITTED') return json({ error: 'Attempt already submitted or missing.' }, 409);
        const t = db.tests.find(x => x.id === a.testId);
        let ls = 0, rs = 0, correct = 0, wrong = 0, unanswered = 0;
        for (const sec of ['listening', 'reading']) for (const q of t.sections[sec]) {
          const ans = a.answers[q.id];
          if (!ans) unanswered++;
          else if (+ans === q.correct) { correct++; sec === 'listening' ? ls += q.points : rs += q.points; }
          else wrong++;
        }
        a.status = 'SUBMITTED';
        a.submittedAt = now();
        a.scores = { listening: ls, reading: rs, writing: null, total: ls + rs, correct, wrong, unanswered };
        for (const q of t.sections.writing || []) {
          const answer = a.writing[q.id] || '';
          const ai = scoreWriting(q, answer);
          db.writing.push({ id: id(), attemptId: a.id, userId: user.id, testId: t.id, question: q, answer, status: 'AI SCORED', score: ai.score, feedback: ai.feedback, ai });
        }
        updateAttempt(db, a.id);
        saveDb(db);
        return json(a);
      }
      if (u.pathname.startsWith('/api/review/')) {
        const a = db.attempts.find(x => x.id === u.pathname.split('/').pop() && x.userId === user.id && x.status === 'SUBMITTED');
        if (!a) return json({ error: 'Result not found' }, 404);
        return json({ attempt: a, test: db.tests.find(x => x.id === a.testId), writing: db.writing.filter(x => x.attemptId === a.id && x.userId === user.id) });
      }

      return json({ error: 'Not found' }, 404);
    } catch (e) {
      return json({ error: e.message || 'Offline app error' }, 500);
    }
  };

  function updateAttempt(db, attemptId) {
    const a = db.attempts.find(x => x.id === attemptId);
    if (!a) return;
    const reviewed = db.writing.filter(x => x.attemptId === a.id && (x.status === 'AI SCORED' || x.status === 'REVIEWED'));
    const total = reviewed.reduce((s, x) => s + Number(x.score || 0), 0);
    a.scores.writing = reviewed.length ? total : null;
    a.scores.total = Number(a.scores.listening || 0) + Number(a.scores.reading || 0) + total;
  }
})();
