KEEP THESE FILES SAFE.

Play Store updates for this app need the same upload keystore.

Keystore file:
upload-keystore.jks

Alias:
hanguktopik_upload

Store password:
Q7eV32by0xPX-BUKxZdMXxL0

Key password:
Q7eV32by0xPX-BUKxZdMXxL0

Do not share this file publicly.
