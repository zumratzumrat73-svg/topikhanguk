# HANGUK TOPIK Android APK wrapper

This Android version bundles the HANGUK TOPIK web app inside the APK.

It opens directly after install and does not need `127.0.0.1`, hotspot, LAN mode, or a PC server.

Current production-style behavior:

- user accounts are stored locally on the phone
- attempts/results are stored locally on the phone
- admin/test builder works locally on the phone
- bundled offline writing scoring works locally

Important: this is an installable standalone app, but it is not yet a cloud-synced multi-user production backend. For shared accounts/admin data across all users, host the backend on a public HTTPS server and point the Android app to that public API.

Build in Android Studio:

1. Open `android-app`.
2. Install Android SDK/build tools if Android Studio asks.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Debug APK path: `android-app/app/build/outputs/apk/debug/app-debug.apk`.
5. Play Store bundle path: `android-app/app/build/outputs/bundle/release/app-release.aab`.
