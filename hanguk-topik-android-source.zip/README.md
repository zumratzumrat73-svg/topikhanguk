# HANGUK TOPIK Android APK wrapper

This is a lightweight Android WebView wrapper for testing the local HANGUK TOPIK web app on real phones.

It does not bundle the Node.js backend. Your PC must run the app server in LAN mode:

```powershell
cd C:\Users\i7\Documents\Codex\2026-07-04\can-u\app
$env:HOST="0.0.0.0"
C:\Users\i7\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe .\server.mjs
```

Then install the APK and enter your PC URL, for example:

```text
http://192.168.1.25:4173
```

Build in Android Studio:

1. Open `android-app`.
2. Install Android SDK/build tools if Android Studio asks.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK path: `android-app/app/build/outputs/apk/debug/app-debug.apk`.
